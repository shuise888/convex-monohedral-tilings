"""Verify the finite rational inequalities and screening tables in the manuscript.

Uses exact integers and fractions from the Python standard library.
Inputs: manuscript-input/. Results: results/current-tables-results.json.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import defaultdict, Counter
import re, json, math, hashlib, sys, datetime

HERE = Path(__file__).resolve().parent
(HERE/'results').mkdir(exist_ok=True)
SOURCE = HERE / 'manuscript-input'
FAILURES = []
COUNTS = Counter()
DETAILS = {}

def check(ok, label, detail=None):
    COUNTS[label] += 1
    if not ok:
        FAILURES.append({'label': label, 'detail': str(detail)})

def table(n):
    return (SOURCE/'input'/f'table-{n:02}-zh.tex').read_text(encoding='utf-8').replace(r'\textendash{}','-').replace(r'\delta','d').replace(r'\boldsymbol\mu',r'\mu')

def body_rows(text):
    body = text.split(r'\endlastfoot',1)[1].split(r'\end{longtable}',1)[0]
    for entry in re.split(r'\\\\(?:\[[^]]*\])?',body):
        entry=re.sub(r'(?m)%[^\n]*','',entry).strip()
        if '&' in entry and not entry.startswith(('\\','%')):
            yield [x.strip().strip('$').strip() for x in entry.split('&')]

def nums(s):
    return tuple(int(x) for x in re.findall(r'-?\d+',s))

def angles(f,a):
    return {'R':(a,90-a,F(90)), 'A':(a,60-2*a/3,120-a/3),
            'B':(a,90-3*a/2,90+a/2), 'C':(a,60-a,F(120))}[f]

def vertices(aa):
    # Cartesian-product enumeration; exact rational equality. No solved variable.
    out = set()
    for f in (0,1):
        total = 180*(2-f)
        for r,s,t in product(*(range(int(total//a)+1) for a in aa)):
            if r*aa[0]+s*aa[1]+t*aa[2] == total and r+s+t+f >= 3:
                out.add((r,s,t,f,r+s+t+f))
    return out

def parity(v):
    return -1 if v[3] else int(len({x%2 for x in v[:3]})>1)

def filter_types(vv,K):
    vv=set(vv); trace=[]
    if K is None: return vv,trace
    while True:
        mu=[min((v[4]-2 for v in vv if v[i]),default=None) for i in range(3)]
        check(None not in mu,'screening has all corner roles',(K,mu))
        if None in mu: return set(),trace
        bad=set()
        for v in vv:
            q=v[4]
            for role in range(4):
                if v[role] and q-2+sum(mu[j] for j in range(3) if j!=role)>K:
                    bad.add(v)
        trace.append((tuple(mu),bad))
        if not bad: return vv,trace
        vv-=bad

def slack(v,c):
    return sum(x*y for x,y in zip(c,(*v[:3],parity(v))))-v[4]*(v[4]-2)

def typed(v):
    return v[:4]

# Bind all input-table bytes to actual delivered Chinese source and compare the
# formula/number content with the delivered English tables.
zh=(SOURCE/'zh/main.tex').read_text(encoding='utf-8')
for n in range(1,42):
    text=table(n)
    raw=(SOURCE/'input'/f'table-{n:02}-zh.tex').read_text(encoding='utf-8')
    check(raw in zh,'table embedded in current Chinese source',n)
    en=(SOURCE/'en/tables'/f'table-{n:02}.tex').read_text(encoding='utf-8')
    def math_tokens(s):
        # Headers differ typographically between languages; compare the exact
        # mathematical table bodies, with caption coefficients checked below.
        s=s.split(r'\endlastfoot',1)[1]
        s=re.sub(r'\\ensuremath\{((?:[^{}]|\{[^{}]*\})*)\}',lambda m:'$'+m.group(1)+'$',s)
        s=s.replace(r'\textendash{}','-').replace(r'\delta','d').replace(r'\boldsymbol\mu',r'\mu')
        s=re.sub(r'\\caption(?:\[[^]]*\])?\{[^\n]*','',s)
        return [re.sub(r'\s+','',x) for x in re.findall(r'\$(.*?)\$',s,re.S)]
    check(math_tokens(text)==math_tokens(en),'Chinese English table body math identical',n)

# Negative-balance enumeration gives all 55 witnesses, and all 24 exceptions.
weights={'R':((1,2,3),6),'A':((3,4,11),18),'B':((2,3,7),12),'C':((1,1,4),6)}
affine={'R':((F(1),F(-1),F(0)),(0,90,90)),
        'A':((F(1),F(-2,3),F(-1,3)),(0,60,120)),
        'B':((F(1),F(-3,2),F(1,2)),(0,90,90)),
        'C':((F(1),F(-1),F(0)),(0,60,120))}
exceptions={}
for n,fam in enumerate('RABC',2):
    ww,k=weights[fam]; witnesses=set(); exc=set()
    for h in (1,2):
        for r,s,t in product(*(range((k*h-1)//w+1) for w in ww)):
            if r*ww[0]+s*ww[1]+t*ww[2]>=k*h: continue
            neg=(r<s and s+t>2*h) if fam=='R' else (s+t>2*h) if fam=='B' else s+2*t>3*h
            if not neg: continue
            witnesses.add((h,t,s,r))
            slopes,off=affine[fam]
            den=sum(x*y for x,y in zip((r,s,t),slopes))
            check(den!=0,'exception witness denominator nonzero',(fam,h,r,s,t))
            a=(180*h-sum(x*y for x,y in zip((r,s,t),off)))/den
            check(0<a<30,'exception witness in angle range',(fam,a))
            exc.add(a)
    printed=set()
    for row in body_rows(table(n)):
        for i in range(0,len(row),4):
            if not row[i]: continue
            h,t,s=map(int,row[i:i+3])
            for r in nums(row[i+3]): printed.add((h,t,s,r))
    check(witnesses==printed,'negative balance printed list complete',(fam,witnesses^printed))
    exceptions[fam]=exc
    DETAILS[f'negative_balance_{fam}']={'witnesses':len(witnesses),'angles':sorted(map(str,exc))}
printed_exceptions=set()
for row in body_rows(table(6)):
    for i in (0,4):
        fam=row[i]; aa=tuple(map(F,row[i+1:i+4]))
        check(aa==angles(fam,aa[0]),'printed exceptional angles exact',(fam,aa))
        printed_exceptions.add((fam,aa[0]))
check(printed_exceptions=={(f,a) for f,es in exceptions.items() for a in es},'24 exceptional triples complete')

# Thirty-one upper-bound rows, every retained type, every printed endpoint and
# every deletion round. Read coefficients directly from the current LaTeX.
upper_rows=list(body_rows(table(7)))
check(len(upper_rows)==31,'upper coefficient row count')
previous={}; ordinary_checks=0
for stage,row in enumerate(upper_rows,1):
    fam=row[0]; a=F(row[1]); K=None if row[2]=='-' else int(row[2]); c=tuple(map(F,row[4:8])); bound=F(row[8]); aa=angles(fam,a)
    check(K is None or K==math.floor(previous[(fam,a)]),'next upper bound budget justified',stage)
    previous[(fam,a)]=bound
    full=vertices(aa); active,trace=filter_types(full,K)
    check(len(active)==int(row[3]),'upper retained type count',stage)
    check(c[3]>=0 and sum(c[:3])==bound,'upper coefficient sum and sign',stage)
    for v in active:
        check(slack(v,c)>=0,'upper ordinary local inequality',(stage,v,slack(v,c)))
        ordinary_checks+=1
    tt=table(stage+8); caption=tt.splitlines()[1]
    p_angles=re.search(r'角度(?:（单位：度）)? \$\((.*?)\)\$',caption).group(1)
    check(tuple(map(F,p_angles.split(',')))==aa,'endpoint caption angle',stage)
    L=int(re.search(r'\$L=(\d+)\$',caption).group(1))
    A,B,C,D=nums(re.search(r'L\(u,v,w,z\)=\((.*?)\)',caption).group(1))
    check(L>0 and tuple(F(x,L) for x in (A,B,C,D))==c,'endpoint integer coefficients',stage)
    check(int(re.search(r'共(\d+)种候选顶点类型',caption).group(1))==len(active),'endpoint caption count',stage)
    pp=nums(re.search(r'\(k_1,k_2,k_3\)=\((.*?)\)',caption).group(1)); HH=int(re.search(r'\\Lambda=(\d+)',caption).group(1))
    check(HH==sum(pp) and tuple(180*F(x,HH) for x in pp)==aa,'endpoint primitive angle weights',stage)
    check(math.gcd(*pp)==1,'endpoint primitive angle gcd',stage)
    printed_groups={}
    for rr in body_rows(tt):
        for j in range(0,len(rr),4):
            if not rr[j]: continue
            printed_groups[nums(rr[j])]=(nums(rr[j+1]),nums(rr[j+2]),int(rr[j+3]))
    groups=defaultdict(list)
    for v in active: groups[(v[3],v[2],parity(v))].append(v)
    check(set(printed_groups)==set(groups),'endpoint group coverage',stage)
    for key,vv in groups.items():
        vv.sort(key=lambda v:v[1]); lo,hi=vv[0],vv[-1]
        expected=((lo[1],hi[1]),tuple(int(L*slack(v,c)) for v in ([lo] if lo==hi else [lo,hi])),len(vv))
        check(printed_groups.get(key)==expected,'endpoint printed exact data',(stage,key))
    printed_mus=[nums(x) for x in re.findall(r'\\mu=\((.*?)\)',caption)]
    printed_deleted=[set(tuple(nums(v)) for v in re.findall(r'\(([^()]+)\)',chunk)) for chunk in re.findall(r'\[\((.*?)\)\]',caption)]
    # The regex above strips the external parentheses of each list: parse the
    # complete list using literal_eval instead of interpreting LaTeX as code.
    import ast
    printed_deleted=[set(map(tuple,ast.literal_eval(x))) for x in re.findall(r'\[\([^\]]*\)\]',caption)]
    check(printed_mus==[mu for mu,bad in trace],'endpoint all round minima',(stage,printed_mus,trace))
    check(printed_deleted==[bad for mu,bad in trace if bad],'endpoint all round deletions',(stage,printed_deleted,trace))
check(ordinary_checks==581,'581 ordinary inequality total',ordinary_checks)
check(all(v<22 for v in previous.values()),'22 ordinary angles bounded below 22')
check(set(previous)==printed_exceptions-{('R',F(18)),('C',F(15))},'upper branches cover 22 ordinary exceptions')

# Upper special R18: complete 22 types, 22+18 inequalities.
special18=vertices((F(18),F(72),F(90)))
ex18={(20,0,0,0):0,(0,5,0,0):0,(0,0,4,0):0,(0,0,2,1):1}
seen=set(); special_upper=0
for row in body_rows(table(40)):
    for j in (0,4):
        v4=nums(row[j]); q=sum(v4); v=(*v4,q); r,s,t,f=v4
        check(v in special18 and int(row[j+1])==q,'R18 printed type degree',v)
        d=18*r+3*s+2*t-q*(q-2)
        d0=90*r+14*s+10*t-5*f+5*int(v4==(0,5,0,0))-5*q*(q-2)
        check(int(row[j+2])==d0 and d0>=0,'R18 first printed slack',v); special_upper+=1
        if v4 in ex18: check(row[j+3]==f'd={d}' and d==ex18[v4],'R18 exceptional deficit',v)
        else:
            d1=8*d-9*s-29*t-29*f
            check(int(row[j+3])==d1 and d1>=0,'R18 second printed slack',v); special_upper+=1
        seen.add(v)
check(seen==special18,'R18 all candidates present')

# The 15-45-120 upper bound now has a geometric/curvature proof in the article.
# Its former four weighted stages and 98 slacks are no longer input data.
# Keep the full candidate set: it is still required for the N=21 exclusion.
special15=vertices((F(15),F(45),F(120)))
check(special_upper==40,'40 upper special inequalities',special_upper)

# Equality exclusion: independently regenerate under N=21 and check every
# printed candidate and rational slack, not just each row's minimum.
equality_rows=list(body_rows(table(8))); text_eq=table(41)
check(len(equality_rows)==22,'22 equality coefficient rows')
eq_ordinary=eq_special=0
for i,row in enumerate(equality_rows,1):
    fam=row[0]; a=F(row[1]); c=tuple(map(F,row[2:6])); bound=F(row[6]); full=vertices(angles(fam,a)); active,trace=filter_types(full,21)
    check(c[3]>=0 and sum(c[:3])==bound and bound<21,'equality coefficient sum sign bound',i)
    head=text_eq.split(f'% BEGIN_CASE rigid-margin-{i} C{i}\n',1)[1].split(f'% BEGIN_CASE_DATA rigid-margin-{i}',1)[0]
    nn=nums(re.search(r'初始 (\d+)，筛选后 (\d+)',head).group(0))
    check(nn==(len(full),len(active)),'equality initial retained counts',i)
    printed_mus=[nums(x) for x in re.findall(r'\\mu=\((.*?)\)',head)]
    # Equality tables omit a final stable round; only actual deletion rounds.
    check(printed_mus==[mu for mu,bad in trace if bad],'equality round minima',i)
    printed_deleted=set((*nums(x),) for x in re.findall(r'删除 (.*?)。',head) for x in re.findall(r'\$\((.*?)\)\$',x))
    expected_deleted={typed(v) for mu,bad in trace for v in bad}
    check(printed_deleted==expected_deleted,'equality deletion coverage',i)
    data=text_eq.split(f'% BEGIN_CASE_DATA rigid-margin-{i}\n',1)[1].split(f'% END_CASE_DATA rigid-margin-{i}',1)[0]
    seen=set()
    for typ,margin in re.findall(r'\$\((\d+,\d+,\d+;[01])\)\$\s*&\s*\$(-?[\d/]+)\$',data):
        v4=nums(typ); v=(*v4,sum(v4)); d=slack(v,c)
        check(v in active and F(margin)==d and d>=0,'equality ordinary printed slack',(i,v,margin,d))
        seen.add(v); eq_ordinary+=1
    check(seen==active,'equality ordinary candidate completeness',i)
for i,vv,remove,cc,L in [(1,special18,{(20,0,0,0)},(63,12,8,0),4),(2,special15,{(24,0,0,0),(21,1,0,0),(18,2,0,0)},(341,135,-60,240),20)]:
    data=text_eq.split(f'% BEGIN_CASE_DATA rigid-special-margin-{i}\n',1)[1].split(f'% END_CASE_DATA rigid-special-margin-{i}',1)[0]
    active={v for v in vv if typed(v) not in remove}; seen=set()
    for typ,margin in re.findall(r'\$\((\d+,\d+,\d+;[01])\)\$\s*&\s*\$(-?[\d/]+)\$',data):
        v4=nums(typ); v=(*v4,sum(v4)); d=sum(x*y for x,y in zip(cc,(*v4[:3],parity(v))))-L*v[4]*(v[4]-2)
        check(v in active and F(margin)==d and d>=0,'equality special printed slack',(i,v,margin,d))
        seen.add(v); eq_special+=1
    check(seen==active,'equality special candidate completeness',i)
check(eq_ordinary==378,'378 equality ordinary inequalities',eq_ordinary)
check(eq_special==44,'44 equality special inequalities',eq_special)
result={'run_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'scope':'exact finite arithmetic and printed table comparison only; geometric premises and unrestricted theorem are not certified','checks':dict(COUNTS),'failure_count':len(FAILURES),'failures':FAILURES,'details':DETAILS,'inequality_counts':{'upper_ordinary':ordinary_checks,'upper_special':special_upper,'equality_ordinary':eq_ordinary,'equality_special':eq_special},'source_sha256':hashlib.sha256((SOURCE/'zh/main.tex').read_bytes()).hexdigest()}
(HERE/'results/current-tables-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'failure_count':len(FAILURES),'failures':FAILURES,'inequality_counts':result['inequality_counts'],'check_count':sum(COUNTS.values())},ensure_ascii=True,indent=2))
raise SystemExit(bool(FAILURES))
