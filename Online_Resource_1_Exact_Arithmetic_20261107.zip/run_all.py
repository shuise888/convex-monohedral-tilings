"""Reproduce the exact table and construction checks. Run: python run_all.py."""
from pathlib import Path
import hashlib,json,subprocess,sys

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'input-manifest.json').read_text(encoding='utf-8'))
for row in manifest['inputs']:
    p=ROOT/row['path']
    if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
        raise SystemExit('Input checksum mismatch: '+row['path'])
for file in ['current_tables_checker.py','construction_checker.py']:
    subprocess.run([sys.executable,str(ROOT/file)],cwd=ROOT,check=True)
tables=json.loads((ROOT/'results/current-tables-results.json').read_text(encoding='utf-8'))
geometry=json.loads((ROOT/'results/construction-results.json').read_text(encoding='utf-8'))
expected=json.loads((ROOT/'expected/summary.json').read_text(encoding='utf-8'))
assert tables['failure_count']==expected['failures']==0
assert tables['inequality_counts']==expected['inequality_counts']
assert sum(tables['checks'].values())==expected['check_count']
for actual,reference in zip(geometry['representatives'],expected['construction_representatives'],strict=True):
    for field,value in reference.items():assert actual[field]==value,(field,actual)
assert geometry['necessary_degree_lists_checked']==expected['necessary_degree_lists']
assert geometry['zero_curvature_lists']==expected['zero_curvature_lists']
print('All checks passed: 1043 inequalities; 6 representatives with 21 neighbors; 653 degree lists.')
