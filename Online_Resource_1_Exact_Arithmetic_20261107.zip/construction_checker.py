"""Exact rational geometry and N=21 local curvature preflight.

Coordinates use the triangular lattice basis (1,0),(1/2,sqrt(3)/2).
The affine coordinate change preserves contact and intersection dimension.
The finite patch exhausts possible neighbors by coordinate bounding boxes.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
(HERE/'results').mkdir(exist_ok=True)

def cross(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def intersects(A,B):
    for P in (A,B):
        for a,b in zip(P,P[1:]+P[:1]):
            dx,dy=b[0]-a[0],b[1]-a[1]
            xx=[dy*x-dx*y for x,y in A]; yy=[dy*x-dx*y for x,y in B]
            if max(xx)<min(yy) or max(yy)<min(xx): return False
    return True

def segment_contact(A,B):
    for a,b in zip(A,A[1:]+A[:1]):
        for c,d in zip(B,B[1:]+B[:1]):
            if cross(a,b,c)==cross(a,b,d)==0:
                k=0 if a[0]!=b[0] else 1
                if min(max(a[k],b[k]),max(c[k],d[k]))>max(min(a[k],b[k]),min(c[k],d[k])):
                    return True
    return False

tiles={}
for i,j in product(range(-3,4),repeat=2):
    for side,tri in [('up',[(i,j),(i+1,j),(i,j+1)]),('down',[(i+1,j),(i,j+1),(i+1,j+1)])]:
        center=tuple(sum(F(v[k]) for v in tri)/3 for k in (0,1))
        for k in range(3):
            tiles[(i,j,side,k)]=[center,tuple(map(F,tri[k])),tuple(map(F,tri[(k+1)%3]))]
reports=[]
for side,k in product(('up','down'),range(3)):
    key=(0,0,side,k); T=tiles[key]
    neighbors=[kk for kk,P in tiles.items() if kk!=key and intersects(T,P)]
    edge=[kk for kk in neighbors if segment_contact(T,tiles[kk])]
    vertex_degrees=[sum(all(cross(P[a],P[(a+1)%3],v)>=0 for a in range(3)) or all(cross(P[a],P[(a+1)%3],v)<=0 for a in range(3)) for P in tiles.values()) for v in T]
    # SAT bounding boxes show i,j outside [-1,1] cannot contact this tile, so the
    # larger [-3,3]^2 patch cannot omit a touching tile.
    assert all(-1<=kk[0]<=1 and -1<=kk[1]<=1 for kk in neighbors)
    assert len(neighbors)==21 and len(edge)==3 and sorted(vertex_degrees)==[3,12,12]
    reports.append({'representative':key,'neighbors':len(neighbors),'segment_neighbors':len(edge),'point_only_neighbors':len(neighbors)-len(edge),'vertex_degrees':vertex_degrees,'neighbor_ids':neighbors})

degree_set=sorted({l+t+f for f in (0,1) for t in range(4) for l in range(13) if l+4*t+6*f==12 and l+t+f>=3})
assert degree_set==[3,4,6,7,9,12]

def lists(m,total,lower=3):
    if m==0:
        if total==0: yield ()
        return
    for q in range(lower,min(12,total//m)+1):
        if total-q>12*(m-1): continue
        for tail in lists(m-1,total-q,q): yield (q,)+tail

possible=[]
for m in range(3,22):
    for qq in lists(m,21+2*m):
        curvature=1-F(m,2)+sum(F(1,q) for q in qq)
        assert curvature<=0
        possible.append((qq,curvature))
zeros=[qq for qq,c in possible if c==0]
assert zeros==[(3,12,12)]
result={'evidence_level':'exact-check','scope':'exhaustive contact check for explicit periodic construction and finite necessary degree-list calculation; not a proof of global uniqueness','representatives':reports,'complete_degree_set':degree_set,'necessary_degree_lists_checked':len(possible),'zero_curvature_lists':zeros,'closest_negative_curvature':str(max(c for qq,c in possible if c<0))}
(HERE/'results/construction-results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='representatives'},indent=2))
